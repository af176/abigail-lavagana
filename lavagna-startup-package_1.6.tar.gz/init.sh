#!/bin/sh
cd project
docker-compose up --build